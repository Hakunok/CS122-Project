# Whale
Aekn Admal, Huy Tran

A Balatro inspired 2D casino-themed dice-building roguelike.

## requirements
- python 3.12.x
- pip

## setup and run

```bash
# on mac/linux, do equivalent for windows
python -m venv .venv
source .venv/bin/activate
pip install -e .
# pip install -r requirements.txt (you shouldnt need to do this)
python whale/main.py
```
