from __future__ import annotations

HANDS_PER_POT = 3
REROLLS_PER_HAND = 2

BASE_POT_TARGET = 300
POT_GROWTH_FACTOR = 1.3
